#include "eulerdata.h"
#include <QDebug>
EulerData::EulerData()
{

}

EulerData::~EulerData()
{

}
