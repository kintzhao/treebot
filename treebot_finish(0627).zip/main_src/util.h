#ifndef UTIL_H
#define UTIL_H
#include <QWidget>
QByteArray intToByteArray(const int i);
#endif // UTIL_H

