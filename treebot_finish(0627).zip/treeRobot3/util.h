#ifndef UTIL_H
#define UTIL_H
#include <QWidget>
QByteArray uin16ToByteArrat(const quint16 i);
QByteArray intToByteArray(const int i);
#endif // UTIL_H

